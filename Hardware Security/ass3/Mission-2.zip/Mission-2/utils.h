#include <stdio.h>

#define MSG_FILE "msg.txt"
#define MAX_MSG_SIZE 500

double check_accuracy(char*, int);